
import { Route, Routes } from "react-router-dom";
import Cabinet from "./pages/cabinet";
import Index from "./pages/index";
import './App.css'

const App = () => (
  <>
    <Routes>
      <Route element={<Index />} path='/' />
      <Route element={<Cabinet />} path='/cabinet'/>
    </Routes>
  </>

)

export default App;