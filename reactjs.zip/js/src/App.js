
import { Route, Routes } from "react-router-dom";
import Cabinet from "./pages/Cabinet.js";
import Index from "./pages/index.js";
import Posts from "./pages/Posts.js";
import Registration from "./pages/Registration.js"
import Login from "./pages/Login.js"
import './App.css'

const App = () => (
  <>
    <Routes>
      <Route element={<Index />} path='/' />
      <Route element={<Cabinet />} path='/cabinet' />
      <Route element={<Posts />} path='/posts' />
      <Route element={<Registration />} path='/registration' />
      <Route element={<Login />} path='/login' />
    </Routes>
  </>

)

export default App;