import React from "react";
import { Link } from "react-router-dom";
import { useState } from "react";

// const Welcome = () => {

//   const navigate = useNavigate()
//   const dispath = useDispatch()
//   const store = useSelector(state => state)

//   const [type, setType] = useState(1);


//   const [login, setLogin] = useState("")
//   const [loginReg, setLoginReg] = useState("")
//   const [pass, setPass] = useState("")
//   const [pass1, setPass1] = useState("")
//   const [pass2, setPass2] = useState("")

//   const checkUser = () => {
//     return store.users.users.find(v => v.name === loginReg)
//   }

//   const findUser = () => {
//     return store.users.users.find(v => v.name === login && v.password === pass)
//   }

//   const signIn = () => {
//     let user = findUser()
//     if (user) {
//       dispath(({ type: "add", id: user.id, name: user.name, password: user.password }));
//       navigate("/cabinet")
//     } else {
//       showError("Неверный логин или пароль.")
//     }
//   }

//   const signUp = () => {
//     if (pass1 !== pass2) {
//       showError("Введенные пароли не совпадают.")
//       return
//     }

//     if (checkUser()) {
//       showError("Данный пользователь уже зарегистрирован.")
//       return
//     }

//     dispath(({ type: "addUser", name: loginReg, password: pass1 }))
//     alert("Пользователь создан.")
//   }

//   return (
//     <>
//       <Layout>
//         <div className="main_block">
//            <div 
//             style={{textAlign: "center", minHeight: "40px", visibility: error ? "visible" : "hidden", color: "red", maxWidth: "400px"}}>
//             {error}
//           </div>
//         </div>
//       </Layout>
//     </>
//   );
// }

const Navigation = () => {

  const [error] = useState();

  return (
    <>
      <div className="main_block">
        <div className="login">
          <h1>
            Главная
          </h1>
          <span>
            <Link to="/login">Вход</Link>
          </span>
          <span>
            <Link to="/registration">Регистрация</Link>
          </span>
          <div
            style={{ textAlign: "center", minHeight: "40px", visibility: error ? "visible" : "hidden", color: "red", maxWidth: "400px" }}>
            {error}
          </div>
        </div>
      </div>
    </>
  );
};

export default Navigation;