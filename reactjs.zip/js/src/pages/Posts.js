import React from "react";
import { Link } from "react-router-dom";

const Posts = () => {
    return (
        <>
            <div className="main_block">
                <div className="login">
                    <span>Вы еще не сделали ни одного поста.</span>
                    <button className="button">Создать</button>
                    <span>
                        <Link to="/cabinet">Назад</Link>
                    </span>
                </div>
            </div>
        </>
    )

}

export default Posts;