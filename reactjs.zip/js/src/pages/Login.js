import React from "react"
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

const Welcome = () => {

  const navigate = useNavigate()
  const dispath = useDispatch()
  const store = useSelector(state => state)

  const [error, setError] = useState();

  const showError = (text) => {
    setError(text)
    setTimeout(() => setError(false), 1500)
  }

  const [login, setLogin] = useState("")
  const [pass, setPass] = useState("")

  const findUser = () => {
    return store.users.users.find(v => v.name === login && v.password === pass)
  }

  const signIn = () => {
    let user = findUser()
    if (user) {
      dispath(({ type: "add", id: user.id, name: user.name, password: user.password }));
      navigate("/cabinet")
    } else {
      showError("Неверный логин или пароль.")
    }
  }

  return (
    <>
      <div className="main_block">
        <div className="login">
          <h2>Войти</h2>
          <span>Логин</span>
          <input
            className="input"
            value={login}
            onChange={(e) => setLogin(e.target.value)}
          />
          <span>Пароль</span>
          <input
            className="input"
            type="password"
            value={pass}
            onChange={(e) => setPass(e.target.value)}
          />
          <button
            className="button"
            onClick={signIn}
            disabled={!login || !pass}
          >
            Войти
          </button>
          <span>
            <Link to='/registration'>Регистрация</Link>
          </span>
          <span>
            <Link to='/'>На главную</Link>
          </span>
          <div
            style={{ textAlign: "center", minHeight: "40px", visibility: error ? "visible" : "hidden", color: "red", maxWidth: "400px" }}>
            {error}
          </div>
        </div>
      </div>
    </>
  );
}

export default Welcome;